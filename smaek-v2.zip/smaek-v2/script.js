// ── Auth ──
function getSession() {
  return JSON.parse(localStorage.getItem('smaek_session') || 'null');
}
function requireAuth() {
  const s = getSession();
  if (!s) { location.href = 'login.html'; return null; }
  return s;
}
function logout() {
  localStorage.removeItem('smaek_session');
  location.href = 'login.html';
}

// ── Data helpers ──
function getData(key) {
  return JSON.parse(localStorage.getItem('smaek_' + key) || '[]');
}
function saveData(key, arr) {
  localStorage.setItem('smaek_' + key, JSON.stringify(arr));
}
function nextId(arr) {
  return arr.length ? Math.max(...arr.map(x => x.id || 0)) + 1 : 1;
}

// ── Toast ──
function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast ' + type + ' show';
  setTimeout(() => t.classList.remove('show'), 3000);
}

// ── Modal ──
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// ── Render sidebar user ──
function renderSidebarUser(sess) {
  const el = document.getElementById('sidebarUser');
  if (!el || !sess) return;
  el.innerHTML = `
    <div class="user-av">${sess.name[0].toUpperCase()}</div>
    <div class="user-info">
      <div class="user-name">${sess.name}</div>
      <div class="user-role">${sess.role}</div>
    </div>
    <button class="btn-logout" onclick="logout()" title="Logout">✕</button>
  `;
}

// ── Stars ──
function renderStars(n, max = 5) {
  return Array.from({length: max}, (_, i) =>
    `<span class="star ${i < n ? 'on' : ''}">★</span>`
  ).join('');
}

// ── Seed sample data if empty ──
function seedData() {
  if (!getData('anggota').length) {
    saveData('anggota', [
      {id:1, nama:'Andi Pratama', kelas:'X-A', jenis:'Anggota Inti', bonus:'Ya', disiplin:'Baik', bergabung:'2024-01-15'},
      {id:2, nama:'Siti Rahayu', kelas:'X-B', jenis:'Anggota Biasa', bonus:'Tidak', disiplin:'Cukup', bergabung:'2024-02-01'},
      {id:3, nama:'Budi Santoso', kelas:'XI-A', jenis:'Anggota Inti', bonus:'Ya', disiplin:'Baik', bergabung:'2023-08-10'},
      {id:4, nama:'Dewi Lestari', kelas:'XI-B', jenis:'Anggota Biasa', bonus:'Ya', disiplin:'Baik', bergabung:'2023-09-05'},
      {id:5, nama:'Rizky Firmansyah', kelas:'XII-A', jenis:'Anggota Inti', bonus:'Tidak', disiplin:'Kurang', bergabung:'2023-07-20'},
    ]);
  }
  if (!getData('disiplin').length) {
    saveData('disiplin', [
      {id:1, anggotaId:5, nama:'Rizky Firmansyah', tanggal:'2024-03-10', jenis:'Terlambat', keterangan:'Terlambat latihan 30 menit', status:'Dicatat'},
      {id:2, anggotaId:2, nama:'Siti Rahayu', tanggal:'2024-03-15', jenis:'Absen', keterangan:'Tidak hadir tanpa izin', status:'Dicatat'},
    ]);
  }
  if (!getData('latihan').length) {
    saveData('latihan', [
      {id:1, tanggal:'2024-03-01', materi:'Teknik Dasar', durasi:120, catatan:'Latihan berjalan lancar', peserta:[1,2,3]},
      {id:2, tanggal:'2024-03-08', materi:'Formasi & Strategi', durasi:90, catatan:'Fokus pada koordinasi tim', peserta:[1,3,4,5]},
      {id:3, tanggal:'2024-03-15', materi:'Uji Coba Internal', durasi:180, catatan:'Simulasi pertandingan', peserta:[1,2,3,4,5]},
    ]);
  }
  if (!getData('prestasi').length) {
    saveData('prestasi', [
      {id:1, anggotaId:1, nama:'Andi Pratama', judul:'Juara 1 Lomba Regional', tanggal:'2024-02-20', tingkat:'Kota', poin:100},
      {id:2, anggotaId:3, nama:'Budi Santoso', judul:'Juara 2 Lomba Provinsi', tanggal:'2024-01-15', tingkat:'Provinsi', poin:200},
      {id:3, anggotaId:4, nama:'Dewi Lestari', judul:'Peserta Terbaik', tanggal:'2024-03-01', tingkat:'Sekolah', poin:50},
    ]);
  }
  if (!getData('pelanggaran').length) {
    saveData('pelanggaran', [
      {id:1, anggotaId:5, nama:'Rizky Firmansyah', tanggal:'2024-03-12', jenis:'Pelanggaran Ringan', deskripsi:'Menggunakan HP saat latihan', sanksi:'Teguran lisan', status:'Selesai'},
    ]);
  }
}
