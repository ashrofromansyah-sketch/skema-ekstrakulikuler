// sidebar.js — inject sidebar into any page
function injectSidebar(activePage) {
  const nav = [
    { section: 'Utama', items: [
      { href:'dashboard.html', icon:'📊', label:'Dashboard', id:'dashboard' },
    ]},
    { section: 'Manajemen', items: [
      { href:'anggota.html',   icon:'👥', label:'Anggota',         id:'anggota' },
      { href:'disiplin.html',  icon:'📋', label:'Disiplin',        id:'disiplin' },
      { href:'pelanggaran.html',icon:'⚠️',label:'Pelanggaran',     id:'pelanggaran' },
    ]},
    { section: 'Aktivitas', items: [
      { href:'latihan.html',   icon:'🏃', label:'Catatan Latihan', id:'latihan' },
      { href:'riwayat.html',   icon:'📅', label:'Riwayat Latihan', id:'riwayat' },
    ]},
    { section: 'Capaian', items: [
      { href:'prestasi.html',  icon:'🏆', label:'Prestasi',        id:'prestasi' },
    ]},
    { section: 'Laporan', items: [
      { href:'laporan.html',   icon:'📄', label:'Laporan Anggota', id:'laporan' },
    ]},
  ];

  const html = `
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="logo-mark">// smaek</div>
      <div class="logo-name">SMAEK_</div>
    </div>
    <nav class="nav">
      ${nav.map(s => `
        <div class="nav-section">
          <div class="nav-section-label">${s.section}</div>
          ${s.items.map(i => `
            <a class="nav-item${i.id===activePage?' active':''}" href="${i.href}">
              <span class="ni">${i.icon}</span>${i.label}
            </a>
          `).join('')}
        </div>
      `).join('')}
    </nav>
    <div class="sidebar-user" id="sidebarUser"></div>
  </aside>`;

  document.body.insertAdjacentHTML('afterbegin', html);
}
